import pyautogui as pag
import editable 
import time
import os


def main():
    BOT_NAMES: list = ["Protein", "CoCoBamBino", "VortexRider", "Kress", "Phoenix", "[zZ]Genji", "Snacks", "Shimon", "StyleFree", "[Xdye]CooLeR[S]", "[SaL]DickStyle[bG]"]
    
    for bot in BOT_NAMES:
        print(f"Starting BOT: {bot}")
        file_content = editable.generate_settings_file(NICKNAME=bot, SERVER_IP='fxp.samp.co.il:7777')
        
        with open("RakSAMPClient.xml", "w") as file:
            file.write(file_content)
        
        os.startfile("RakSAMPClient.exe")
                        
        time.sleep(150.5)



if __name__ == "__main__":
    main()
